<?php

$HOST = "111.118.182.147";
//$HOST = "localhost";
?>

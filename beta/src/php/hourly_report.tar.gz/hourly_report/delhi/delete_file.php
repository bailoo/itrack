<?php
function delete_file($file)
{
	unlink($file);	
}

?>
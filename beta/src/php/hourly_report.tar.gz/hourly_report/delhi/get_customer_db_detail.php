﻿<?php
function get_customer_db_detail()
{
	global $DbConnection;
	global $account_id;
	global $customer_input;
	global $station_id;
	global $type;
	global $customer_no;
	global $station_name;	
	global $station_coord;
	global $distance_variable;
	
	$customer_input_string = "";
	$customer_input_string2 = "";

	for($k=0;$k<sizeof($customer_input);$k++)		
	{
		if($k==0)
		{
			$customer_input_string = $customer_input_string."".$customer_input[$k];
			$customer_input_string2 = $customer_input_string2." customer_no like '".$customer_input[$k]."@%'";
		}
		else
		{
			$customer_input_string = $customer_input_string.",".$customer_input[$k];
			$customer_input_string2 = $customer_input_string2." OR customer_no like '".$customer_input[$k]."@%'";
		}
	}

	//##### GET STATION COORDINATES -CUSTOMER ###############
	$query2 = "SELECT DISTINCT station_id,type,customer_no,station_name,station_coord,distance_variable,google_location FROM station WHERE ".
				"user_account_id='$account_id' AND (customer_no IN(".$customer_input_string.") OR ".$customer_input_string2.") AND type=0 AND status=1";

	//echo "\n".$query2;
	/*			
	$query2 = "SELECT DISTINCT station_id,type,customer_no,station_name,station_coord,distance_variable,google_location FROM station WHERE ".
				"user_account_id='$account_id' AND customer_no IN(71189) AND type=0 AND status=1";			
	//echo "\nQ1=".$query2;
	*/	
	$result2 = mysql_query($query2,$DbConnection); 

	while($row2 = mysql_fetch_object($result2))
	{
	  $station_id[] = $row2->station_id;
	  $type[] = $row2->type;
	  $customer_no[] = $row2->customer_no;
	  $station_name[] = $row2->station_name;
	  //$station_coord_tmp =  $row2->station_coord;
	  $station_coord[] = $row2->station_coord;
	  $distance_variable[] = $row2->distance_variable;	  
	  //$google_location[] = $row2->google_location;
	  //$google_location[] = $placename1;
	} 

	//##### GET STATION COORDINATES -PLANT ###############
	$query2 = "SELECT DISTINCT station_id,type,customer_no,station_name,station_coord,distance_variable,google_location FROM station WHERE ".
				"user_account_id='$account_id' AND type=1 AND status=1";
	/*			
	$query2 = "SELECT DISTINCT station_id,type,customer_no,station_name,station_coord,distance_variable,google_location FROM station WHERE ".
				"user_account_id='$account_id' AND customer_no IN(71189) AND type=1 AND status=1";			
	//echo "\nQ2=".$query2;
	*/
	$result2 = mysql_query($query2,$DbConnection); 

	while($row2 = mysql_fetch_object($result2))
	{
	  $station_id[] = $row2->station_id;
	  $type[] = $row2->type;
	  $customer_no[] = $row2->customer_no;
	  $station_name[] = $row2->station_name;
	  //$station_coord_tmp =  $row2->station_coord;
	  $station_coord[] = $row2->station_coord;
	  $distance_variable[] = $row2->distance_variable;	  
	  //$google_location[] = $row2->google_location;
	  //$google_location[] = $placename1;
	} 
}
?>  
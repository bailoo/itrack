﻿<?php

function get_route_db_detail($shift)
{
	global $DbConnection;
	global $account_id;
	global $vehicle_name_rdb;		//VEHICLE ROUTE DETAIL
	global $route_name_rdb;

	if($shift == "evening")
	{
		$query = "SELECT DISTINCT vehicle_name_ev,route_name_ev FROM route_assignment2 WHERE user_account_id='$account_id' AND NOT(route_name_ev='') AND status=1";				
		$result = mysql_query($query,$DbConnection); 

		while($row = mysql_fetch_object($result))
		{
		  $vehicle_name_rdb[] = $row->vehicle_name_ev;
		  $route_name_rdb[] = $row->route_name_ev;
		} 
	}	
	else if($shift == "morning")
	{
		$query = "SELECT DISTINCT vehicle_name_mor,route_name_mor FROM route_assignment2 WHERE user_account_id='$account_id' AND NOT(route_name_mor='') AND status=1";				
		$result = mysql_query($query,$DbConnection); 

		while($row = mysql_fetch_object($result))
		{
		  $vehicle_name_rdb[] = $row->vehicle_name_mor;
		  $route_name_rdb[] = $row->route_name_mor;
		} 
	}
}
?>  
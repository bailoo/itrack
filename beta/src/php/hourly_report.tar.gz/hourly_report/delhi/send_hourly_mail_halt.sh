#!/usr/bin/php
cd /var/www/html/vts/beta/src/php/daily_report/motherdairy/delhi/hourly_mail
php mail_hourly_halt_report.php



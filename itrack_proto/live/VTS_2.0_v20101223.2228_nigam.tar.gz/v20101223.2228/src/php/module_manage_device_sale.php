<tr>
  <td>  
      <table class="manage_menu">						  				 
  			<tr>
  				<td class="menuNormal" width="70" height="20">							
  					<strong>
  						<a href="javascript:show_option('manage','device_sale');" class="menuitem">&nbsp;Device Sale</a>
  					</strong>
  				</td>
			</tr>
		</table>
	</td>
</tr> 						
<tr>
  <td>  
      <table class="menu" width="150">						  				 
  			<tr>
  				<td class="menuNormal" width="154" height="20" onmouseover="expand(this);" onmouseout="collapse(this);">							
  					<strong>
  						&nbsp;DataLog
  					</strong>
  					<div class="menuNormal" width="150">
  						<table class="menu" width="150">  							
                <tr>
                  <td class="menuNormal"><a href="javascript:report_datalog_today();" class="menuitem">Today's Record</a></td>
                </tr>                
                <tr>
                  <td class="menuNormal"><a href="javascript:report_datalog_date();" class="menuitem">Specify Date</a></td>
                </tr>	
                
                <tr>
                 <td class="menuNormal"><a href="javascript:report_datalog_vehicle();" class="menuitem">Specify Vehicle</a></td>
                </tr>		
                <tr>
                  <td class="menuNormal"><a href="javascript:report_datalog_search();" class="menuitem">Search Vehicle</a></td>
                </tr>		                               		                					
						</table>
				</td>
			</tr>
		</table>
	</td>
</tr> 					

 
	
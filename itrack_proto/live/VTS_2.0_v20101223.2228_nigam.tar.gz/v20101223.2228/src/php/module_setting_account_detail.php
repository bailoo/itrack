<tr>
  <td>  
      <table class="menu" width="150">						  				 
  			<tr>
  				<td class="menuNormal" width="154" onmouseover="expand(this);" onmouseout="collapse(this);">							
  					<strong>
  						<a class="menuitem" href="javascript:setting_account_detail();">Account Detail</a>
  					</strong>  				
				</td>
			</tr>
		</table>
	</td>
</tr> 					


	
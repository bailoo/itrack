<tr>
  <td>  
      <table class="menu" width="150">						  				 
  			<tr>
  				<td class="menuNormal" width="154" height="20" onmouseover="expand(this);" onmouseout="collapse(this);">							
  					<strong>
  						&nbsp;Alert
  					</strong>
  					<div class="menuNormal" width="150">
  						<table class="menu" width="150">  						
  							<tr>
								    <td class="menuNormal"><a href="javascript:alert_area_violation();" class="menuitem">Area violation</a></td>
							   </tr>							
							 <tr>
								    <td class="menuNormal"><a href="javascript:alert_speed_violation();" class="menuitem">Speed violation</a></td>
							 </tr>							
						</table>
				</td>
			</tr>
		</table>
	</td>
</tr> 					

 
	
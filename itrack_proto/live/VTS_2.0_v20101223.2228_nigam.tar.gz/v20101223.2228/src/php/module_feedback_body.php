<table width="100%">
  <tr class="mb2">
    <td valign="top">
      <center>

        <!--<div id="main_body" style="position:relative;overflow-x:hidden;overflow-y:auto;height:450px;">-->
        <span id="bodyspan"> </span>     
        <!--<span id="bodyspan" style="position:relative;overflow-x:hidden;overflow-y:auto;height:450px;"> </span>           
       </div>-->
      </center> 
    </td>
  </tr>
</table>
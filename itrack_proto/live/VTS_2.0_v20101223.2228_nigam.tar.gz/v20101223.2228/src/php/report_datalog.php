<?php
  include_once('util_session_variable.php');
  include_once('util_php_mysql_connectivity.php');

	$userid = $_GET['UserID'];


		include('user_datalog_menu.php');		


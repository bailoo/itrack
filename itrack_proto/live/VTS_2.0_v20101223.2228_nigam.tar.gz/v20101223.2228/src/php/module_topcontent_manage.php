<td>
  <?php
    include_once('welcome_msg.php');
  ?>
</td>
<td align="right">
  <a href="manage1.php">Home</a>&nbsp;|&nbsp; 
  <a href="Logout.php">Logout</a>
</td>
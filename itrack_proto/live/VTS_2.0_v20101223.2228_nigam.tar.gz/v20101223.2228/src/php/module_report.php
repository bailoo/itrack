<tr>
  <td>  
      <table class="menu" width="150">						  				 
  			<tr>
  				<td class="menuNormal" width="154" height="20" onmouseover="expand(this);" onmouseout="collapse(this);">							
  					<strong>
  						&nbsp;Regular
  					</strong>
  					<div class="menuNormal" width="150">
  						<table class="menu" width="150">  							
                <tr>
                  <td class="menuNormal"><a href="javascript:report_vehicle();" class="menuitem">Vehicle Report</a></td>
                </tr>
                
                <tr>
                  <td class="menuNormal"><a href="javascript:report_speed();" class="menuitem">Speed Report</a></td>
                </tr>	
                
                <tr>
                 <td class="menuNormal"><a href="javascript:report_distance();" class="menuitem">Distance Report</a></td>
                </tr>		
                <tr>
                  <td class="menuNormal"><a href="javascript:report_monthly_distance();" class="menuitem">Monthly Distance</a></td>
                </tr>		
                
                <tr>
                  <td class="menuNormal"><a href="javascript:report_fuel();" class="menuitem">Fuel Report</a></td>
                </tr>
                
               <tr>
                  <td class="menuNormal"><a href="javascript:report_halt();" class="menuitem">Halt Report</a></td>
                </tr>                
                
                <tr>
                  <td class="menuNormal"><a href="javascript:report_summary();" class="menuitem">Summary Report</a></td>
                </tr>		
                                                           									                					
						</table>
				</td>
			</tr>
		</table>
	</td>
</tr> 					

 
	
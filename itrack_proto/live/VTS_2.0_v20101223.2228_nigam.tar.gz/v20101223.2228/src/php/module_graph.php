<tr>
  <td>  
      <table class="menu" width="150">						  				 
  			<tr>
  				<td class="menuNormal" width="154" height="20" onmouseover="expand(this);" onmouseout="collapse(this);">							
  					<strong>
  						&nbsp;Graph
  					</strong>
  					<div class="menuNormal" width="150">
  						<table class="menu" width="150">
  							<tr>
  								  <td class="menuNormal"><a href="javascript:graph_daily_speed();" class="menuitem">Speed Graph</a></td>
  							</tr>
  							<tr>
								    <td class="menuNormal"><a href="javascript:graph_daily_distance();" class="menuitem">Distance Graph</a></td>
							   </tr>							
							 <tr>
								    <td class="menuNormal"><a href="javascript:graph_daily_fuel();" class="menuitem">Fuel Graph</a></td>
							 </tr>							
						</table>
				</td>
			</tr>
		</table>
	</td>
</tr> 						
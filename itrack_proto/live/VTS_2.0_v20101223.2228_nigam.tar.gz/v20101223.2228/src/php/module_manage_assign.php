<tr>
  <td>  
      <table class="manage_menu">						  				 
  			<tr>
  				<td class="menuNormal" width="154" height="20" onmouseover="expand(this);" onmouseout="collapse(this);">							
  					<strong>
  						&nbsp;Assignment
  					</strong>
  					<div class="menuNormal" width="150">
  						<table class="menu" width="150">
				        <tr>				          
  								  <td class="menuNormal"><a href="javascript:show_option('manage','device_vehicle_assignment');" class="menuitem">Device Vehicle Assignment</a></td>
  							</tr>  							
                <tr>
  								  <td class="menuNormal"><a href="#" class="menuitem">Landmark Assignment</a></td>
  							</tr>
				        <tr>
				            
  								  <td class="menuNormal"><a href="javascript:manage_geofence_assignment();" class="menuitem">Geofence Assignment</a></td>
  							</tr>  						
			           <tr>
  								  <td class="menuNormal"><a href="javascript:manage_route_assignment();" class="menuitem">Route Assignment</a></td>
  							</tr>  						
						
						</table>
				</td>
			</tr>
		</table>
	</td>
</tr> 					

 
	
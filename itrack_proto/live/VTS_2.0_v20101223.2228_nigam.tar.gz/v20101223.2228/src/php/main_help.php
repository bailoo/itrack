<html>  
  <head>      
     <?php
        include('main_frame_part1.php');
     ?>
  </head>
  
<body bgcolor="lightgrey" topmargin="0" onresize="javascript:resize()" onload="javascript:resize()">
  <?php 

    include('main_frame_part2.php');
    include('module_frame_header.php');
    include('main_frame_part3.php');
    include('module_help_menu.php');
    include('main_frame_part4.php');
    include('module_help_body.php');
    include('main_frame_part5.php');
  ?>	
</body>
            
</html>
  
 <title>Vehicle Tracking System 2.0</title>
  <meta http-equiv="Content-Type" content="text/html; charset=">
  <meta name="keywords" content="vehicle tracking, gps tracking, gps vehcile tracking, surveillance, gps, tracking, tracking device,tracing,latitude and longitude,gsm modem, car tracking, analyzer,path finder, path locater,way finder,plotter,gps technology">
  <meta name="description" content=""> 
  
  <link rel="shortcut icon" href="images/iesicon.ico" >
  <link rel="StyleSheet" href="src/css/menu.css">	
  <link rel="StyleSheet" href="src/css/module_hide_show_div.css">	
  <link rel="stylesheet" href="src/css/calendar.css">
  
  <script type="text/javascript" src="src/js/util.js"></script>
  <script type="text/javascript" src="src/js/markers.js"></script>  
  <script type="text/javascript" src="src/js/jquery.js"></script>   
  <script type="text/javascript" src="src/js/main.js"></script> 
  <script type="text/javascript" src="src/dragzoom/gzoom.js"></script> 
  <script type="text/javascript" src="src/js/menu.js"></script>
  <!--<script language="javascript" src="src/js/simplecalendar.js"></script>-->
  <script language="javascript" src="src/js/calendar_us.js"></script> 
  <script language="javascript" src="src/js/ajax.js"></script>
  
   <script type="text/javascript">
document.write('<script type="text/javascript" src="src/js/extlargemapcontrol'+(document.location.search.indexOf('packed')>-1?'_packed':'')+'.js"><'+'/script>');
</script>
 
  <script language="javascript" src="src/js/manage.js"></script> 
  <script language="javascript" src="src/js/setting.js"></script>
  <script language="javascript" src="src/js/report.js"></script>      
  <script language="javascript" src="src/js/validation.js"></script>
  <script language="javascript" src="src/js/datetimepicker.js"></script>
  <script language="javascript" src="src/js/datetimepicker_sd.js"></script>

  <script language="javascript" src="src/js/ashish.js"></script>
  <script language="javascript" src="src/js/shams.js"></script>
  <script language="javascript" src="src/js/riz.js"></script>
        
  <script language="javascript" src="src/js/feedback.js"></script>       

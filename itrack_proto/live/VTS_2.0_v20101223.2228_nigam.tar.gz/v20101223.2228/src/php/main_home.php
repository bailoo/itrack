<html>  
  <head> 
  
     
     <?php
        //include('main_google_key.php');        
        include('main_frame_part1.php');
     ?>      
  </head>
  
<body bgcolor="lightgrey" topmargin="0"  onload="javascript:resize('home')"  onresize="javascript:resize('home')">

  <?php 
    include('main_frame_part2.php');
    include('module_frame_header.php');
    include('main_frame_part3.php');
    include('module_home_menu.php');
    include('main_frame_part4.php');
    include('module_home_body.php');    
    include('main_frame_part5.php');
  ?>	
</body>
            
</html>
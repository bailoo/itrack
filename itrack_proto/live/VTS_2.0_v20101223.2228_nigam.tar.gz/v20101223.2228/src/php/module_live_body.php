<table width="100%">
  <tr>
    <td>
      <h1> <center> Live </center> </h1>
    </td>
  </tr>
</table>
<?php ?>  
  <td>
    <table width="100%" class='module_left_menu'>
      <tr>
        <td>
         Symbols For Speed
        </td>
      </tr>
      <tr>
        <td>
        <img src="images/yellow_Marker_bottom.png" alt="4">
          	1>>20 &nbsp;&nbsp;&nbsp;&nbsp; 
        <img src="images/green_Marker_bottom.png" alt="2">
        >20
		 &nbsp;&nbsp;&nbsp;&nbsp;
        <img src="images/red_Marker_bottom.png" alt="3">
        <1
		  &nbsp;&nbsp;&nbsp;&nbsp;
        <img src="images/blink_Marker.gif" alt="1" width="10" height="16">
        Current         	
        </td>
      </tr>
    </table>
  </td>
</tr>

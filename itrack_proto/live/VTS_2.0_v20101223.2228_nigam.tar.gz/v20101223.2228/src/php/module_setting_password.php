<tr>
  <td>  
      <table class="menu" width="150">						  				 
  			<tr>
  				<td class="menuNormal" width="154" onmouseover="expand(this);" onmouseout="collapse(this);">							
  					<strong>
  						  <a class="menuitem" href="javascript:setting_password();">Password</a>
  					</strong>  				
				</td>
			</tr>
		</table>
	</td>
</tr>
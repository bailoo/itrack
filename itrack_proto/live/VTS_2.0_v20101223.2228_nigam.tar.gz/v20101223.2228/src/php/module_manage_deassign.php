<tr>
  <td>  
      <table class="manage_menu">						  				 
  			<tr>
  				<td class="menuNormal" width="154" height="20" onmouseover="expand(this);" onmouseout="collapse(this);">							
  					<strong>
  						&nbsp;DeAssignment
  					</strong>
  					<div class="menuNormal" width="150">
  						<table class="menu" width="150">
				        <tr>				          
  								  <td class="menuNormal"><a href="javascript:show_option('manage','device_vehicle_deassignment');" class="menuitem">Device Vehicle DeAssignment</a></td>
  							</tr>  							
                <tr>
  								  <td class="menuNormal"><a href="#" class="menuitem">Landmark DeAssignment</a></td>
  							</tr>
				        <tr>				            
  								  <td class="menuNormal"><a href="javascript:manage_geofence_vehicle_deassignment();" class="menuitem">Geofence DeAssignment</a></td>
  							</tr>  						
			           <tr>
  								  <td class="menuNormal"><a href="javascript:manage_route_vehicle_deassignment();" class="menuitem">Route DeAssignment</a></td>
  							</tr>  						
						
						</table>
				</td>
			</tr>
		</table>
	</td>
</tr> 					

 
	
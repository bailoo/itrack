<table width="100%">
  <tr>
    <td>
      <h1> <center> Help </center> </h1>
    </td>
  </tr>
</table>
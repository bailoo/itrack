<?php    
  echo '<div id="map" style="height:100%;width:100%;display:none;"></div>
        <div id="text" class="module_text">
          <div style="height:210px;"> </div>
           <center>show message</center>
        </div>';
?>
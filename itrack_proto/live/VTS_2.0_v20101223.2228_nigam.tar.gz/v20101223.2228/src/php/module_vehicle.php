<?php ?>
<tr>
  <td>
    <table border="0" class='module_left_menu'>
      <tr>
        <td colspan=''>
            Select Vehicles
        </td>
      </tr>
      <tr>
        <td>
          Group By
				</td>  				
				<td>
				  None
				</td>
				<td>
				  Type
				</td>
				<td>
				  Tag
				</td> 				
      </tr>
	  <tr>
        <td colspan=''>
            <div style="height:200px"></div>
        </td>
      </tr>
    </table>
  </td>
</tr>


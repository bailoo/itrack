<div style="overflow-x:hidden;overflow-y:auto;" id="leftMenu_1"> 
        <div id="bodyspan" style="height:100%;width:100%;"></div>
</div>

 <!--
<table width="100%">
  <tr class="mb2">
    <td valign="top">
      <center>

         <span id="bodyspan"> </span>     
       
      </center> 
    </td>
  </tr>
</table>  -->
<tr>
  <td>  
      <table class="menu" width="150">						  				 
  			<tr>
  				<td class="menuNormal" width="154" height="20">							
  					<strong>
  						 <a href="javascript:show_option('manage','geofence');" class="menuitem">&nbsp;Geofencing</a>
  					</strong>
				</td>
			</tr>
		</table>
	</td>
</tr> 					

 
	
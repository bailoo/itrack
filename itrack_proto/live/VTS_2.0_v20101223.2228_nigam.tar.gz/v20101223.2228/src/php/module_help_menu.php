<table border='1' width="100%" height="100%">
    <tr  class="mb1">
      <td>
          <?php include('module_logo.php');?> 
      </td>
    </tr>
  <tr  class="mb2">
    <td valign="top">
       <div style="overflow-x:hidden;overflow-y:auto;" id="leftMenu">
          <table border='1' width="100%">		           
              <?php
                echo '<tr> <td> Home Menu </td> </tr>';
              ?>  		          
          </table>
      </div>	
   </td>
  </tr>
  <tr  class="mb3">
      <td>
          <?php include('module_copyright.php');?>
      </td>
  </tr>
</table>					
  	    

		  